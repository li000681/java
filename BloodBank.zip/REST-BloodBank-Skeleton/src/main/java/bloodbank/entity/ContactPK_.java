package bloodbank.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-31T23:31:53.034-0400")
@StaticMetamodel(ContactPK.class)
public class ContactPK_ {
	public static volatile SingularAttribute<ContactPK, Integer> personId;
	public static volatile SingularAttribute<ContactPK, Integer> phoneId;
}
