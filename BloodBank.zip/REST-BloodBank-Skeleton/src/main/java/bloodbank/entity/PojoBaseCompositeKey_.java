package bloodbank.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-31T23:32:03.882-0400")
@StaticMetamodel(PojoBaseCompositeKey.class)
public class PojoBaseCompositeKey_ {
	public static volatile SingularAttribute<PojoBaseCompositeKey, Integer> version;
	public static volatile SingularAttribute<PojoBaseCompositeKey, Long> epochCreated;
	public static volatile SingularAttribute<PojoBaseCompositeKey, Long> epochUpdated;
}
