package bloodbank.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-31T23:31:53.033-0400")
@StaticMetamodel(BloodType.class)
public class BloodType_ {
	public static volatile SingularAttribute<BloodType, String> bloodGroup;
	public static volatile SingularAttribute<BloodType, Byte> rhd;
}
