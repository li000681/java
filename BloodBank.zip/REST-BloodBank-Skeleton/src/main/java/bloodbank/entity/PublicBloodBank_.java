package bloodbank.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-31T23:32:00.936-0400")
@StaticMetamodel(PublicBloodBank.class)
public class PublicBloodBank_ extends BloodBank_ {
}
